import React, { Component } from 'react'
import Navbar from './Navbar'

class Home extends Component {

    render() {
        return (
            <>
               
               <Navbar />

            </>
        )
    }
}

export default Home