<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<base href="<?php echo base_url()?>">
        <meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
	<title>Data Tamu Undangan</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/uikit.min.css'?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/datatables.min.css'?>">
<style>
.uk-navbar-nav li a{font-size:1.125rem}
</style>
</head>