<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
    <title>Ucapan/Konfirmasi - The Wedding Akbar &amp; Risa</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/uikit.min.css'?>">
</head>
<body>

<div class="uk-container uk-container-medium">
  <div class="uk-alert-success" uk-alert>
    <a class="uk-alert-close" uk-close></a>
    <h3>Notice</h3>
    <p>Terima kasih anda sudah konfirmasi dan mengisi Ucapan &amp; Doa untuk Putra-Putri kami Akbar dan Risa.</p>
</div>     


</div>     
                

<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-2.1.4.min.js'?>"></script>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/uikit.min.js'?>"></script>

    <script type="text/javascript" src="<?php echo base_url().'assets/js/uikit-icons.min.js'?>"></script>
    
</body>
</html>