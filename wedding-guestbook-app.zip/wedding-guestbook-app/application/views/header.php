<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
		<title>Buku Tamu - The Wedding Raffi &amp; Ayu</title>
   <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Merriweather" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/custom.css'?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/uikit.min.css'?>">
	
<style>
.naik-keatas{margin-top: -50px;}

</style>
	</head>