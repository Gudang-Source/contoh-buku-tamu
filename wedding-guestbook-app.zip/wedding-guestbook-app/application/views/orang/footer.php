<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-2.1.4.min.js'?>"></script>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/uikit.min.js'?>"></script>

    <script type="text/javascript" src="<?php echo base_url().'assets/js/uikit-icons.min.js'?>"></script>

</body>
</html>