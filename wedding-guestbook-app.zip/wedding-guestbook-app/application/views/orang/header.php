<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
	<title>Ucapan dan Konfirmasi - The Wedding</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/uikit.min.css'?>">

    <style>
.text-grey-900 {
  color: #212121 !important;
}
a.text-grey-900:hover,
a.text-grey-900:focus {
  color: #080808;
}
</style>
</head>